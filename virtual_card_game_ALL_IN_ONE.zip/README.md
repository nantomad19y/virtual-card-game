# Virtual Card Game — Online Demo

## ເປັນຫຍັງມີໂປຣເຈັກນີ້
- Login/Profile
- Virtual Coins
- Demo top-up (ບໍ່ຮັບເງິນຈິງ)
- Daily bonus
- History
- ໄພ້ແຄງ 6 ບ່ອນນັ່ງ
- Poker 8 ບ່ອນນັ່ງ
- ໄພ້ແຕ້ມ
- Create Room / Join Room / Random Room
- Real-time room sync ຜ່ານ Socket.IO
- SQLite database

## ເປີດໃຊ້
1. ຕິດຕັ້ງ Node.js 18+.
2. ເປີດ Terminal ຢູ່ໂຟນເດີນີ້.
3. ຮັນ:
   npm install
   npm start
4. ເປີດ:
   http://localhost:3000

## ເອົາຂຶ້ນ Online
ນຳ project ນີ້ໄປ deploy ໃສ່ Node.js hosting ທີ່ຮອງຮັບ WebSocket + persistent storage.

## ໝາຍເຫດ
ເວີຊັນນີ້ແມ່ນ prototype. ຮອບເກມເປັນ demo ເທົ່ານັ້ນ; ຍັງບໍ່ແມ່ນກົດກາ Poker/ແຄງ/ແຕ້ມຄົບສົມບູນ.

Virtual Coins ບໍ່ມີມູນຄ່າຈິງ ແລະບໍ່ມີລະບົບຖອນ/ແລກເງິນຈິງ.
