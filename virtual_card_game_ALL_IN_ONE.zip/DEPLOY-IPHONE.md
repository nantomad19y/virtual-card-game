# ວິທີເອົາຂຶ້ນ Online ຈາກ iPhone

## 1) ແຕກ ZIP
ໃຫ້ແຕກ ZIP ແລ້ວໄດ້ໂຄງສ້າງ:
- package.json
- server.js
- render.yaml
- public/index.html

## 2) GitHub
ສ້າງ Repository ໃໝ່ ແລ້ວ upload ໄຟລ໌ທັງໝົດ.

## 3) Render
ເຂົ້າ Render -> New -> Web Service -> ເລືອກ GitHub repository.

ຄ່າ:
Build Command: npm install
Start Command: npm start

## 4) ຫຼັງ Deploy
Render ຈະໃຫ້ URL ເຊັ່ນ:
https://virtual-card-game.onrender.com

ເອົາ URL ນີ້ໃຫ້ຜູ້ຫຼິ້ນເຂົ້າ.

## 5) Room Online
ຜູ້ຫຼິ້ນ:
Create Room -> ໄດ້ Room ID -> ສົ່ງ ID ໃຫ້ໝູ່ -> Join Room.

ໝາຍເຫດ:
- ເວີຊັນນີ້ໃຊ້ Virtual Coins ເທົ່ານັ້ນ.
- Coins ບໍ່ມີມູນຄ່າຈິງ ແລະຖອນ/ແລກເງິນຈິງບໍ່ໄດ້.
- SQLite ອາດຖືກລຶບເມື່ອ service restart/redeploy ຖ້າບໍ່ມີ persistent storage.
