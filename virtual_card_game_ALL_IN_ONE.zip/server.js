const path = require("path");
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const Database = require("better-sqlite3");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const db = new Database("game.db");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  coins INTEGER NOT NULL DEFAULT 1000
);
CREATE TABLE IF NOT EXISTS history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL,
  game TEXT NOT NULL,
  result TEXT NOT NULL,
  coins_change INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

app.use(express.static(path.join(__dirname, "public")));

const rooms = new Map();

function getUser(username) {
  return db.prepare("SELECT * FROM users WHERE username=?").get(username);
}
function ensureUser(username) {
  let u = getUser(username);
  if (!u) {
    db.prepare("INSERT INTO users(username, coins) VALUES(?, 1000)").run(username);
    u = getUser(username);
  }
  return u;
}
function setCoins(username, coins) {
  db.prepare("UPDATE users SET coins=? WHERE username=?").run(coins, username);
}
function addHistory(username, game, result, change) {
  db.prepare("INSERT INTO history(username, game, result, coins_change) VALUES(?,?,?,?)")
    .run(username, game, result, change);
}
function makeRoomId() {
  let id;
  do id = Math.floor(100000 + Math.random() * 900000).toString();
  while (rooms.has(id));
  return id;
}
function roomView(room) {
  return {
    id: room.id,
    game: room.game,
    maxPlayers: room.maxPlayers,
    players: [...room.players.values()].map(p => ({
      username: p.username,
      seat: p.seat
    }))
  };
}
function broadcastRoom(room) {
  io.to(room.id).emit("room:update", roomView(room));
}

io.on("connection", socket => {
  socket.on("login", ({ username }) => {
    username = String(username || "").trim().slice(0, 24);
    if (!username) return socket.emit("error:msg", "ກະລຸນາໃສ່ຊື່");
    const user = ensureUser(username);
    socket.data.username = username;
    socket.emit("login:ok", { username, coins: user.coins });
  });

  socket.on("coins:demoTopup", () => {
    const username = socket.data.username;
    if (!username) return;
    const user = ensureUser(username);
    const newCoins = user.coins + 1000;
    setCoins(username, newCoins);
    addHistory(username, "SYSTEM", "Demo top-up", 1000);
    socket.emit("coins:update", newCoins);
    socket.emit("toast", "ເພີ່ມ 1,000 Virtual Coins ແລ້ວ");
  });

  socket.on("bonus:claim", () => {
    const username = socket.data.username;
    if (!username) return;
    const key = `bonus:${username}:${new Date().toISOString().slice(0,10)}`;
    if (global[key]) return socket.emit("toast", "ຮັບ Bonus ມື້ນີ້ແລ້ວ");
    global[key] = true;
    const user = ensureUser(username);
    setCoins(username, user.coins + 500);
    addHistory(username, "SYSTEM", "Daily bonus", 500);
    socket.emit("coins:update", user.coins + 500);
    socket.emit("toast", "🎁 ໄດ້ Bonus 500 Coins");
  });

  socket.on("history:get", () => {
    const username = socket.data.username;
    if (!username) return;
    const rows = db.prepare(
      "SELECT game,result,coins_change,created_at FROM history WHERE username=? ORDER BY id DESC LIMIT 50"
    ).all(username);
    socket.emit("history:data", rows);
  });

  socket.on("room:create", ({ game }) => {
    const username = socket.data.username;
    if (!username) return;
    const config = game === "poker"
      ? { maxPlayers: 8, name: "Poker" }
      : game === "kaeng"
      ? { maxPlayers: 6, name: "ໄພ້ແຄງ" }
      : { maxPlayers: 6, name: "ໄພ້ແຕ້ມ" };

    const id = makeRoomId();
    const room = {
      id, game, maxPlayers: config.maxPlayers,
      players: new Map(),
      host: username
    };
    room.players.set(socket.id, { username, seat: 1 });
    rooms.set(id, room);
    socket.join(id);
    socket.data.roomId = id;
    socket.emit("room:created", roomView(room));
    broadcastRoom(room);
  });

  socket.on("room:join", ({ roomId }) => {
    const username = socket.data.username;
    const room = rooms.get(String(roomId || "").trim());
    if (!username) return;
    if (!room) return socket.emit("error:msg", "ບໍ່ພົບ Room ID");
    if (room.players.size >= room.maxPlayers) return socket.emit("error:msg", "ຫ້ອງເຕັມແລ້ວ");

    const used = new Set([...room.players.values()].map(p => p.seat));
    let seat = 1;
    while (used.has(seat)) seat++;
    room.players.set(socket.id, { username, seat });
    socket.join(room.id);
    socket.data.roomId = room.id;
    socket.emit("room:joined", roomView(room));
    broadcastRoom(room);
  });

  socket.on("room:random", ({ game }) => {
    const candidates = [...rooms.values()].filter(r =>
      r.game === game && r.players.size < r.maxPlayers
    );
    if (!candidates.length) {
      socket.emit("error:msg", "ຍັງບໍ່ມີຫ້ອງວ່າງ, ລອງສ້າງຫ້ອງໃໝ່");
      return;
    }
    const room = candidates[Math.floor(Math.random() * candidates.length)];
    socket.emit("room:randomFound", roomView(room));
  });

  socket.on("room:leave", () => leaveRoom(socket));

  socket.on("game:demoRound", ({ game }) => {
    const username = socket.data.username;
    const room = rooms.get(socket.data.roomId);
    if (!username || !room) return;
    const user = ensureUser(username);
    const cost = 10;
    if (user.coins < cost) return socket.emit("error:msg", "Coins ບໍ່ພໍ");

    // Demo-only round: server controls the random result.
    const win = Math.random() < 0.5;
    const change = win ? 10 : -10;
    const newCoins = user.coins + change;
    setCoins(username, newCoins);
    addHistory(username, game || room.game, win ? "WIN" : "LOSS", change);

    socket.emit("coins:update", newCoins);
    io.to(room.id).emit("game:result", {
      username,
      result: win ? "WIN" : "LOSS",
      change
    });
  });

  socket.on("disconnect", () => leaveRoom(socket));
});

function leaveRoom(socket) {
  const roomId = socket.data.roomId;
  if (!roomId) return;
  const room = rooms.get(roomId);
  if (!room) return;
  room.players.delete(socket.id);
  socket.leave(roomId);
  socket.data.roomId = null;
  if (!room.players.size) rooms.delete(roomId);
  else broadcastRoom(room);
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Virtual Card Game running on http://localhost:${PORT}`);
});
